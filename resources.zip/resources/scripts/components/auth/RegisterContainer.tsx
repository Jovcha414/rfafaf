import tw from 'twin.macro';
import Reaptcha from 'reaptcha';
import { object, string } from 'yup';
import useFlash from '@/plugins/useFlash';
import register from '@/api/auth/register';
import { useStoreState } from 'easy-peasy';
import { Formik, FormikHelpers } from 'formik';
import Field from '@/components/elements/Field';
import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/elements/button/index';
import { Link, RouteComponentProps } from 'react-router-dom';
import FlashMessageRender from '@/components/FlashMessageRender';
import LoginFormContainer from '@/components/auth/LoginFormContainer';

interface Values {
    username: string;
    email: string;
    password: string;
}

const RegisterContainer = ({ history }: RouteComponentProps) => {
    const ref = useRef<Reaptcha>(null);
    const [token, setToken] = useState('');

    const { clearFlashes, clearAndAddHttpError, addFlash } = useFlash();
    const { enabled: recaptchaEnabled, siteKey } = useStoreState((state) => state.settings.data!.recaptcha);

    useEffect(() => {
        clearFlashes();
    }, []);

    const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();

        if (recaptchaEnabled && !token) {
            ref.current!.execute().catch((error) => {
                console.error(error);
                setSubmitting(false);
                clearAndAddHttpError({ error });
            });

            return;
        }

        register({ ...values, recaptchaData: token })
            .then((response) => {
                if (response.complete) {
                    history.replace('/auth/login');
                    addFlash({
                        key: 'auth:register',
                        type: 'success',
                        message: 'Account has been successfully created.',
                    });
                    return;
                }

                history.replace('/auth/register');
            })
            .catch((error) => {
                console.error(error);

                setToken('');
                if (ref.current) ref.current.reset();

                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
    };

    return (
        <div css={tw`
            w-full h-screen
            flex items-center justify-center
            bg-gradient-to-br from-[#0a0a0b] via-[#0f0f10] to-[#050506]
            relative overflow-hidden
        `}>
            {/* Animated Background Elements */}
            <div css={tw`absolute inset-0 overflow-hidden pointer-events-none`}>
                {/* Gradient Orbs */}
                <div css={tw`
                    absolute top-[-10%] left-[-5%]
                    w-96 h-96
                    bg-[#00ff80] opacity-10
                    rounded-full
                    blur-[120px]
                    animate-pulse
                `} />
                <div css={tw`
                    absolute bottom-[-10%] right-[-5%]
                    w-96 h-96
                    bg-[#00d4ff] opacity-10
                    rounded-full
                    blur-[120px]
                    animate-pulse
                    animation-delay-2000
                `} />

                {/* Grid Pattern */}
                <div css={tw`
                    absolute inset-0
                    bg-[linear-gradient(rgba(0,255,128,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,128,0.03)_1px,transparent_1px)]
                    bg-[size:50px_50px]
                    [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black,transparent)]
                `} />
            </div>

            <div css={tw`flex flex-col items-center relative z-10`}>
                {/* Logo with Enhanced Glow */}
                <div css={tw`relative mb-8 group`}>
                    <div css={tw`
                        absolute inset-0
                        bg-[#00ff80]
                        opacity-40
                        blur-2xl
                        rounded-full
                        scale-150
                        group-hover:opacity-60
                        transition-all duration-500
                    `} />
                    <img
                        src="https://www.elitecappe.com/s.png"
                        css={tw`
                            w-36 h-36
                            relative z-10
                            drop-shadow-[0_0_20px_rgba(0,255,128,0.8)]
                            group-hover:drop-shadow-[0_0_30px_rgba(0,255,128,1)]
                            transition-all duration-500
                            group-hover:scale-105
                        `}
                        alt="Elite Cappe Logo"
                    />
                </div>

                <Formik
                    onSubmit={onSubmit}
                    initialValues={{ username: '', email: '', password: '' }}
                    validationSchema={object().shape({
                        username: string().min(3).required(),
                        email: string().email().required(),
                        password: string().min(8).required(),
                    })}
                >
                    {({ isSubmitting, setSubmitting, submitForm }) => (
                        <LoginFormContainer
                            title={'Create an Account'}
                            css={tw`
                                w-[420px]
                                bg-gradient-to-br from-[#1a1a1c]/80 via-[#151517]/80 to-[#1a1a1c]/80
                                backdrop-blur-xl
                                p-10
                                rounded-2xl
                                border border-neutral-700/50
                                shadow-[0_8px_32px_rgba(0,0,0,0.4),0_0_1px_rgba(0,255,128,0.1)]
                                text-white
                                relative
                                before:absolute before:inset-0
                                before:rounded-2xl
                                before:p-[1px]
                                before:bg-gradient-to-br before:from-[#00ff80]/20 before:via-transparent before:to-[#00d4ff]/20
                                before:[-webkit-mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)]
                                before:[mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)]
                                before:[mask-composite:exclude]
                                hover:shadow-[0_8px_32px_rgba(0,0,0,0.5),0_0_20px_rgba(0,255,128,0.15)]
                                transition-all duration-500
                            `}
                        >
                            {/* Top Accent Line */}
                            <div css={tw`
                                absolute top-0 left-1/2 -translate-x-1/2
                                w-24 h-1
                                bg-gradient-to-r from-transparent via-[#00ff80] to-transparent
                                rounded-full
                                opacity-60
                            `} />

                            <FlashMessageRender byKey={'auth:register'} css={tw`mb-4`} />

                            {/* Form Fields with Better Spacing */}
                            <div css={tw`space-y-5 mt-6`}>
                                <Field
                                    type={'text'}
                                    label={'Username'}
                                    name={'username'}
                                    disabled={isSubmitting}
                                />
                                <Field
                                    type={'email'}
                                    label={'Email Address'}
                                    name={'email'}
                                    disabled={isSubmitting}
                                />
                                <Field
                                    type={'password'}
                                    label={'Password'}
                                    name={'password'}
                                    disabled={isSubmitting}
                                />
                            </div>

                            {/* Enhanced Register Button */}
                            <Button
                                type={'submit'}
                                css={tw`
                                    mt-8 mb-6 w-full
                                    bg-gradient-to-r from-[#00ff80] to-[#00d4aa]
                                    hover:from-[#00ff80] hover:to-[#00ffaa]
                                    text-black font-semibold
                                    shadow-[0_0_20px_rgba(0,255,128,0.3)]
                                    hover:shadow-[0_0_30px_rgba(0,255,128,0.5)]
                                    transition-all duration-300
                                    border-0
                                    hover:scale-[1.02]
                                    active:scale-[0.98]
                                `}
                                size={Button.Sizes.Large}
                                disabled={isSubmitting}
                            >
                                {isSubmitting ? 'Creating Account...' : 'Create Account'}
                            </Button>

                            {recaptchaEnabled && (
                                <Reaptcha
                                    ref={ref}
                                    size={'invisible'}
                                    sitekey={siteKey || '_invalid_key'}
                                    onVerify={(response) => {
                                        setToken(response);
                                        submitForm();
                                    }}
                                    onExpire={() => {
                                        setSubmitting(false);
                                        setToken('');
                                    }}
                                />
                            )}

                            {/* Divider */}
                            <div css={tw`
                                flex items-center gap-4
                                my-6
                            `}>
                                <div css={tw`flex-1 h-[1px] bg-gradient-to-r from-transparent via-neutral-700 to-transparent`} />
                            </div>

                            {/* Return to Login Link */}
                            <div css={tw`text-center`}>
                                <Link
                                    to={'/auth/login'}
                                    css={tw`
                                        text-sm text-neutral-400
                                        tracking-wide
                                        no-underline
                                        uppercase
                                        hover:text-[#00ff80]
                                        transition-colors duration-300
                                        font-medium
                                        relative
                                        inline-block
                                        after:absolute after:bottom-0 after:left-0 after:right-0
                                        after:h-[1px] after:bg-[#00ff80]
                                        after:scale-x-0 hover:after:scale-x-100
                                        after:transition-transform after:duration-300
                                        pb-1
                                    `}
                                >
                                    ← Return to login
                                </Link>
                            </div>
                        </LoginFormContainer>
                    )}
                </Formik>

                {/* Bottom Info Text */}
                <div css={tw`
                    mt-6
                    text-center
                    text-xs
                    text-neutral-500
                    max-w-md
                `}>
                    By creating an account, you agree to our Terms of Service and Privacy Policy
                </div>
            </div>
        </div>
    );
};

export default RegisterContainer;

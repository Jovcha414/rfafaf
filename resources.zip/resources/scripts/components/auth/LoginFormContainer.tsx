import { forwardRef, useEffect, useState } from 'react';
import * as React from 'react';
import { Form } from 'formik';
import styled from 'styled-components';
import { breakpoint } from '@/assets/theme';
import FlashMessageRender from '@/elements/FlashMessageRender';
import tw from 'twin.macro';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const Container = styled.div<{ isVisible: boolean }>`
    opacity: ${({ isVisible }) => (isVisible ? 1 : 0)};
    transition: opacity 0.5s ease-in;
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        const timeout = setTimeout(() => setVisible(true), 50);
        return () => clearTimeout(timeout);
    }, []);

    return (
        <Container isVisible={visible}>
            {title && (
                <h2 css={tw`text-2xl font-bold text-center mb-2 bg-gradient-to-r from-white to-neutral-300 bg-clip-text text-transparent`}>
                    {title}
                </h2>
            )}
            <FlashMessageRender css={tw`mb-4`} />
            <Form {...props} ref={ref}>
                <div css={tw`relative`}>
                    {props.children}
                </div>
            </Form>
        </Container>
    );
});
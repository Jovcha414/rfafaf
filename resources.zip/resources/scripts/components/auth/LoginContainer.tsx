import { useStoreState } from 'easy-peasy';
import type { FormikHelpers } from 'formik';
import { Formik } from 'formik';
import { useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Reaptcha from 'reaptcha';
import tw from 'twin.macro';
import { object, string } from 'yup';

import { login, externalLogin } from '@/api/routes/auth/login';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import Field from '@/elements/Field';
import { Button } from '@/elements/button';
import useFlash from '@/plugins/useFlash';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDiscord, faGoogle } from '@fortawesome/free-brands-svg-icons';
import Label from '@/elements/Label';
import { faAt, faKey, faEnvelope } from '@fortawesome/free-solid-svg-icons';

interface Values {
    username: string;
    password: string;
}

function LoginContainer() {
    const ref = useRef<Reaptcha>(null);
    const token = useRef('');

    const appName = useStoreState(state => state.settings.data!.name);
    const modules = useStoreState(state => state.everest.data!.auth.modules);
    const registration = useStoreState(state => state.everest.data!.auth.registration.enabled);

    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { enabled: recaptchaEnabled, siteKey } = useStoreState(state => state.settings.data!.recaptcha);

    const navigate = useNavigate();

    useEffect(() => {
        clearFlashes();
    }, []);

    const useOauth = (name: string) => {
        externalLogin(name)
            .then(url => {
                // @ts-expect-error this is fine
                window.location = url;
            })
            .catch(error => clearAndAddHttpError({ key: 'auth:login', error }));
    };

    const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();

        if (recaptchaEnabled && !token.current) {
            ref.current!.execute().catch(error => {
                console.error(error);

                setSubmitting(false);
                clearAndAddHttpError({ error });
            });

            return;
        }

        login({ ...values, recaptchaData: token.current })
            .then(response => {
                if (response.complete) {
                    // @ts-expect-error this is valid
                    window.location = response.intended || '/';
                    return;
                }

                navigate('/auth/login/checkpoint', { state: { token: response.confirmationToken } });
            })
            .catch(error => {
                console.error(error);

                token.current = '';
                if (ref.current) ref.current.reset();

                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
    };

    return (
        <div css={tw`w-full h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0a0b] via-[#0f0f10] to-[#050506] relative overflow-hidden`}>
            {/* Animated Background Elements */}
            <div css={tw`absolute inset-0 overflow-hidden pointer-events-none`}>
                {/* Gradient Orbs */}
                <div css={tw`absolute top-[-10%] right-[-5%] w-96 h-96 bg-[#00ff80] opacity-10 rounded-full blur-[120px] animate-pulse`} />
                <div
                    css={tw`absolute bottom-[-10%] left-[-5%] w-96 h-96 bg-[#00d4ff] opacity-10 rounded-full blur-[120px] animate-pulse`}
                    style={{ animationDelay: '2s' }}
                />

                {/* Grid Pattern */}
                <div
                    css={tw`absolute inset-0`}
                    style={{
                        backgroundImage: 'linear-gradient(rgba(0,255,128,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,128,0.03) 1px, transparent 1px)',
                        backgroundSize: '50px 50px',
                        maskImage: 'radial-gradient(ellipse 80% 50% at 50% 50%, black, transparent)'
                    }}
                />
            </div>

            <div css={tw`flex flex-col items-center relative z-10`}>
                {/* Logo with Enhanced Glow */}
                <div css={tw`relative mb-8 group`}>
                    <div css={tw`absolute inset-0 bg-[#00ff80] opacity-40 blur-2xl rounded-full scale-150 group-hover:opacity-60 transition-all duration-500`} />
                    <img
                        src="https://www.elitecappe.com/s.png"
                        css={tw`w-36 h-36 relative z-10 transition-all duration-500 group-hover:scale-105`}
                        style={{
                            filter: 'drop-shadow(0 0 20px rgba(0,255,128,0.8))'
                        }}
                        alt="Logo"
                        onError={(e) => {
                            // Fallback to SVG logo if image fails to load
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            const parent = target.parentElement;
                            if (parent) {
                                const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                                svg.setAttribute('class', 'w-36 h-36 relative z-10');
                                svg.setAttribute('viewBox', '0 0 100 100');
                                svg.innerHTML = `
                                    <circle cx="50" cy="50" r="42" stroke="black" stroke-width="4" fill="none" opacity="0.3"/>
                                    <path d="M30 50L45 65L70 35" stroke="black" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
                                    <text x="50" y="85" font-size="14" fill="black" text-anchor="middle" font-weight="bold">ELITE</text>
                                `;
                                const wrapper = document.createElement('div');
                                wrapper.className = 'w-36 h-36 relative z-10 flex items-center justify-center bg-gradient-to-br from-[#00ff80] to-[#00d4aa] rounded-2xl';
                                wrapper.style.filter = 'drop-shadow(0 0 20px rgba(0,255,128,0.8))';
                                wrapper.appendChild(svg);
                                parent.appendChild(wrapper);
                            }
                        }}
                    />
                </div>

                <Formik
                    onSubmit={onSubmit}
                    initialValues={{ username: '', password: '' }}
                    validationSchema={object().shape({
                        username: string().required('A username or email must be provided.'),
                        password: string().required('Please enter your account password.'),
                    })}
                >
                    {({ isSubmitting, setSubmitting, submitForm }) => (
                        <LoginFormContainer
                            title={`Welcome to ${appName}`}
                            css={tw`
                                w-[420px]
                                bg-gradient-to-br from-[#1a1a1c]/80 via-[#151517]/80 to-[#1a1a1c]/80
                                backdrop-blur-xl
                                p-10
                                rounded-2xl
                                border border-neutral-700/50
                                shadow-[0_8px_32px_rgba(0,0,0,0.4),0_0_1px_rgba(0,255,128,0.1)]
                                text-white
                                relative
                                hover:shadow-[0_8px_32px_rgba(0,0,0,0.5),0_0_20px_rgba(0,255,128,0.15)]
                                transition-all duration-500
                            `}
                        >
                            {/* Gradient Border Effect */}
                            <div
                                css={tw`absolute inset-0 rounded-2xl p-[1px] pointer-events-none -z-10`}
                                style={{
                                    background: 'linear-gradient(135deg, rgba(0,255,128,0.2), transparent, rgba(0,212,255,0.2))',
                                    mask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                                    maskComposite: 'exclude'
                                }}
                            />

                            {/* Top Accent Line */}
                            <div css={tw`absolute top-0 left-1/2 -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-[#00ff80] to-transparent rounded-full opacity-60`} />

                            {/* Form Fields */}
                            <div css={tw`space-y-5 mt-2`}>
                                <Field
                                    icon={faAt}
                                    type={'text'}
                                    label={'Username or Email'}
                                    name={'username'}
                                    disabled={isSubmitting}
                                    placeholder={'user@jexpanel.com'}
                                />

                                <div>
                                    <Label>
                                        Password
                                        <Link
                                            to={'/auth/password'}
                                            tabIndex={-1}
                                            css={tw`ml-2 text-xs text-[#00ff80] hover:text-[#00d4aa] transition-colors duration-300`}
                                        >
                                            Forgot Password?
                                        </Link>
                                    </Label>
                                    <Field
                                        icon={faKey}
                                        type={'password'}
                                        name={'password'}
                                        disabled={isSubmitting}
                                        placeholder={'••••••••••••'}
                                    />
                                </div>
                            </div>

                            {/* Enhanced Login Button */}
                            <div css={tw`mt-8`}>
                                <Button
                                    type={'submit'}
                                    loading={isSubmitting}
                                    size={Button.Sizes.Large}
                                    disabled={isSubmitting}
                                    css={tw`
                                        w-full
                                        bg-gradient-to-r from-[#00ff80] to-[#00d4aa]
                                        hover:from-[#00ff80] hover:to-[#00ffaa]
                                        text-black font-semibold
                                        shadow-[0_0_20px_rgba(0,255,128,0.3)]
                                        hover:shadow-[0_0_30px_rgba(0,255,128,0.5)]
                                        transition-all duration-300
                                        border-0
                                        hover:scale-[1.02]
                                        active:scale-[0.98]
                                    `}
                                >
                                    {isSubmitting ? 'Signing in...' : 'Sign In'}
                                </Button>
                            </div>

                            {recaptchaEnabled && (
                                <Reaptcha
                                    ref={ref}
                                    size={'invisible'}
                                    sitekey={siteKey || '_invalid_key'}
                                    onVerify={response => {
                                        token.current = response;
                                        submitForm();
                                    }}
                                    onExpire={() => {
                                        setSubmitting(false);
                                        token.current = '';
                                    }}
                                />
                            )}

                            {/* Divider with OR */}
                            {(modules.discord.enabled || modules.google.enabled || registration) && (
                                <div css={tw`flex items-center gap-4 my-6`}>
                                    <div css={tw`flex-1 h-[1px] bg-gradient-to-r from-transparent via-neutral-700 to-transparent`} />
                                    <span css={tw`text-xs text-neutral-500 uppercase`}>or</span>
                                    <div css={tw`flex-1 h-[1px] bg-gradient-to-r from-transparent via-neutral-700 to-transparent`} />
                                </div>
                            )}

                            {/* Social Login & Register Buttons */}
                            <div css={tw`grid gap-3 ${modules.discord.enabled && modules.google.enabled ? 'grid-cols-2' : 'grid-cols-1'}`}>
                                {modules.discord.enabled && (
                                    <Button.Info
                                        type={'button'}
                                        onClick={() => useOauth('discord')}
                                        size={Button.Sizes.Small}
                                        css={tw`
                                            bg-[#5865F2]/20
                                            border border-[#5865F2]/40
                                            hover:bg-[#5865F2]/30
                                            hover:border-[#5865F2]/60
                                            transition-all duration-300
                                            text-white
                                        `}
                                    >
                                        <FontAwesomeIcon icon={faDiscord} css={tw`mr-2`} /> Discord
                                    </Button.Info>
                                )}
                                {modules.google.enabled && (
                                    <Button.Text
                                        type={'button'}
                                        onClick={() => useOauth('google')}
                                        size={Button.Sizes.Small}
                                        css={tw`
                                            bg-white/10
                                            border border-white/20
                                            hover:bg-white/20
                                            hover:border-white/30
                                            transition-all duration-300
                                            text-white
                                        `}
                                    >
                                        <FontAwesomeIcon icon={faGoogle} css={tw`mr-2`} /> Google
                                    </Button.Text>
                                )}
                            </div>

                            {registration && (
                                <div css={tw`mt-3`}>
                                    <Button.Text
                                        type={'button'}
                                        onClick={() => navigate('/auth/register')}
                                        size={Button.Sizes.Small}
                                        css={tw`
                                            w-full
                                            bg-neutral-800/50
                                            border border-neutral-700/50
                                            hover:bg-neutral-700/50
                                            hover:border-[#00ff80]/30
                                            transition-all duration-300
                                            text-neutral-300
                                            hover:text-[#00ff80]
                                        `}
                                    >
                                        <FontAwesomeIcon icon={faEnvelope} css={tw`mr-2`} /> Create New Account
                                    </Button.Text>
                                </div>
                            )}
                        </LoginFormContainer>
                    )}
                </Formik>

                {/* Bottom Copyright */}
                <div css={tw`mt-6 text-center text-xs text-neutral-500`}>
                    &copy; {new Date().getFullYear()}{' '}
                    <a
                        href="https://jexpanel.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        css={tw`text-neutral-500 hover:text-[#00ff80] transition-colors duration-300 no-underline`}
                    >
                        Jexpanel.com
                    </a>
                </div>
            </div>
        </div>
    );
}

export default LoginContainer;

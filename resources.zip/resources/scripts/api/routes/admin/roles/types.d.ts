export interface AdminRolePermission {
    key: string;
    description: string;
}

export interface AdminRolePermissionFilters {
    key?: string;
}
